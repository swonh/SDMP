﻿// Copyright (c) 2021-25, Sungwon Hong. All Rights Reserved. 
// This Source Code Form is subject to the terms of the Mozilla Public License, Version 2.0. 
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.

using $safeprojectname$.General.Managers;
using Priority_Queue;
using System.Collections.Generic;
using System.Linq;

namespace $safeprojectname$.General.DataModel
{
    public class State : FastPriorityQueueNode
    {
        public string Key { get; set; }

        public object Data { get; set; }

        public int Index { get; set; }

        public double CurrentBestValue { get; set; }

        public double DualBound { get; set; }

        public double ValueFunctionEstimate { get; set; }

        public double ActionValue { get; set; }

        public double PrimalBound { get; set; }

        public bool IsInitial { get; set; }

        public bool IsLeaf { get; set; }

        public bool IsFinal { get; set; }

        public bool IsLastStage { get; set; }

        public bool IsVisited { get; set; }

        public bool IsFixed { get; set; }

        public bool IsPostActionState { get; set; }

        public bool IsSetDualBound { get; set; }

        public bool IsSetPrimalBound { get; set; }

        public bool IsSetValueFunctionEstimate { get; set; }

        public bool IsValueFunctionCalulated { get; set; }

        public State PreActionState { get; set; }

        public Dictionary<string, State> PrevBestStates { get; set; }

        public State PrevBestState { get; set; }

        public Dictionary<string, State> PrevStates { get; set; }

        public Stage Stage { get; set; }

        public int ClusterID { get; set; }

        public double ClusterDistance { get; set; }


        public State(string key)
        {
            this.Key = key;
            this.PrevStates = new Dictionary<string, State>();
            this.PrevBestStates = new Dictionary<string, State>();
            this.DualBound = BoundManager.Instance.RootDualBound;
        }

        public State()
        {
            this.PrevStates = new Dictionary<string, State>();
            this.PrevBestStates = new Dictionary<string, State>();
            this.DualBound = BoundManager.Instance.RootDualBound;
        }

        public virtual void SetDualBound(double value)
        {
            if (this.IsSetDualBound == false)
            {
                StateManager.Instance.AddDualBoundCalculatedState(this);
            }

            this.DualBound = value;
            this.IsSetDualBound = true;
        }

        public virtual void SetPrimalBound(double value)
        {
            if (this.IsSetPrimalBound == false)
            {
                StateManager.Instance.AddPrimalBoundCalculatedState(this);
            }

            this.PrimalBound = value;
            this.IsSetPrimalBound = true;
        }

        public virtual void SetValueFunctionEstimate(double value)
        {
            if (this.IsSetValueFunctionEstimate == false)
            {
                StateManager.Instance.AddValueFunctionEstimatedState(this);
            }

            this.ValueFunctionEstimate = value;
            this.IsSetValueFunctionEstimate = true;
        }

        public virtual void SetIsValueFunctionCalculated(bool isCalculated)
        {
            if (this.IsValueFunctionCalulated == false)
            {
                StateManager.Instance.AddValueFunctionCalculatedState(this);
            }

            this.IsValueFunctionCalulated = isCalculated;
        }

        public virtual void SetKey(string key)
        {
            this.Key = key;
        }

        public virtual void AddPrevState(State state)
        {
            if (this.PrevStates.ContainsKey(state.Key) == false)
            {
                this.PrevStates.Add(state.Key, state);
            }
        }

        public virtual void SetPrevBestState(State state)
        {
            this.PrevBestState = state;

            if (this.PrevBestStates.ContainsKey(state.Key) == false)
            {
                this.PrevBestStates.Add(state.Key, state);
            }
        }

        public virtual List<State> GetBestStatesBackward()
        {
            List<State> states = new List<State>();

            if (this.PrevBestState == null)
                return states;

            if (this.PrevStates.Count == 0)
                return states;

            State currState = this.PrevBestState;

            states.Add(currState);

            while (currState.IsInitial == false)
            {
                currState = currState.PrevBestState;
                states.Add(currState);
            }

            return states;
        }

        public virtual List<State> GetFirstStatesBackward()
        {
            List<State> states = new List<State>();

            if (this.PrevStates == null)
                return states;

            if (this.PrevStates.Count == 0)
                return states;

            State currState = this.PrevStates.Values.First();

            states.Add(currState);

            while (currState.IsInitial == false)
            {
                currState = currState.PrevStates.Values.First();
                states.Add(currState);
            }

            return states;
        }

        public virtual State Clone()
        {
            State clone = (State)this.MemberwiseClone();

            return clone;
        }

        public override string ToString()
        {
            return this.Key;
        }

    }
}
