﻿// Copyright (c) 2021-25, Sungwon Hong. All Rights Reserved. 
// This Source Code Form is subject to the terms of the Mozilla Public License, Version 2.0. 
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.

using $safeprojectname$.Enum;
using $safeprojectname$.General.Managers;
using $safeprojectname$.Routing.DataModel;
using System;
using System.Collections.Generic;

namespace $safeprojectname$.Routing.Controls
{
    public class NodeControl
    {
        private static readonly Lazy<NodeControl> lazy = new Lazy<NodeControl>(() => new NodeControl());

        public static NodeControl Instance
        {
            get
            {
                if (ControlManager.Instance.RegisteredControls.TryGetValue(ControlType.NodeControl.ToString(), out object control))
                {
                    return (NodeControl)control;
                }
                else
                {
                    return lazy.Value;
                }
            }
        }

        public virtual Dictionary<int, VehicleStateInfo> GetVisitableNodes(Dictionary<int, VehicleStateInfo> vehicleInfos)
        {
            return vehicleInfos;
        }
    }
}
