﻿// Copyright (c) 2021-25, Sungwon Hong. All Rights Reserved. 
// This Source Code Form is subject to the terms of the Mozilla Public License, Version 2.0. 
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.

using $safeprojectname$.General.Controls;
using $safeprojectname$.General.DataModel;
using $safeprojectname$.General.Managers;
using $safeprojectname$.Interfaces;
using $safeprojectname$.Routing.Controls;
using $safeprojectname$.Routing.DataModel;
using Priority_Queue;
using System;
using System.Collections.Generic;
using System.Diagnostics;

namespace $safeprojectname$.Routing.Solver
{
    public class RoutingSolver : ISolver
    {
        public RoutingSolver(IRunConfig runConfig)
        {
            this.RunConfig = runConfig;
            this.StopWatch = new Stopwatch();
            this.VisitedStates = new Dictionary<string, State>();
            this.TransitionQueue = new FastPriorityQueue<State>(Convert.ToInt32(9 * Math.Pow(10, 7)));
            //FastPriorityQueue - Convert.ToInt32(9 * Math.Pow(10, 7)
        }

        protected override void DoInitialStateTransitions(State initialState)
        {
            RoutingState initState = initialState as RoutingState;

            ActionControl transitionControl = ActionControl.Instance;
            StateManager stateManager = StateManager.Instance;
            StateControl stateControl = StateControl.Instance;
            NodeControl nodeControl = NodeControl.Instance;
            ApproximationControl approxControl = ApproximationControl.Instance;

            List<State> newStates = new List<State>();

            List<General.DataModel.StateActionMap> initStateActionMaps = this.GetStateActionMaps(initialState);
            foreach (StateActionMap map in initStateActionMaps)
            {
                map.PostActionState.SetKey(stateControl.GetKey(map.PostActionState));
                map.PostActionState.IsPostActionState = true;
                map.PostActionState.PreActionState = map.PostActionState;
            }

            List<General.DataModel.StateTransition> initStateTransitions = this.GetStateTransitions(initStateActionMaps);

            Stage nextStage = new Stage(initialState.Stage.Index + 1);
            foreach (General.DataModel.StateTransition tran in initStateTransitions)
            {
                State toState = tran.ToState;

                tran.ToState.Stage = nextStage;

                toState.Index = ++this.CurrentStateIndex;
                toState.SetKey(stateControl.GetKey(toState));
                tran.SetIndex(++this.TransitionIndex);

                double cost = tran.Cost;
                double nextValue = initialState.CurrentBestValue + cost;

                toState.CurrentBestValue = nextValue;

                toState.SetPrevBestState(initialState);

                stateManager.SetLinks(tran);
                stateManager.AddState(toState, nextStage);

                if (this.VisitedStates.ContainsKey(toState.Key) == false)
                    this.VisitedStates.Add(toState.Key, toState);

                newStates.Add(toState);
            }

            if (this.CheckLocalFilteringCondition(initialState.Stage.Index))
            {
                int maximumTransitionCount = approxControl.GetLocalTransitionCount();
                int approximationStartStageIndex = approxControl.GetApproximationStartStageIndex();

                newStates = approxControl.FilterLocalStates(initialState, newStates, maximumTransitionCount);
            }

            this.AddNextStates(newStates);
        }

        protected override List<General.DataModel.StateActionMap> GetStateActionMaps(State state)
        {
            RoutingState routingState = state as RoutingState;
            ActionControl actionControl = ActionControl.Instance;
            NodeControl nodeControl = NodeControl.Instance;

            routingState.VehicleStateInfos = nodeControl.GetVisitableNodes(routingState.VehicleStateInfos);
            List<General.DataModel.StateActionMap> maps = actionControl.GetStateActionMaps(state);

            return maps;
        }
    }
}
