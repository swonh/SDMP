﻿// Copyright (c) 2021-25, Sungwon Hong. All Rights Reserved. 
// This Source Code Form is subject to the terms of the Mozilla Public License, Version 2.0. 
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.

using Nodez.Data.Interface;

namespace $safeprojectname$.General.DataModel
{
    public class StateInfoLog : IOutputRow
    {
        // Define columns here (NOTICE: The column name defined here and the column name defined in the data file must match.)

        public int STATE_INDEX { get; set; }

        public int PREV_BEST_STATE_INDEX { get; set; }

        public string STATE_KEY { get; set; }

        public int STAGE_INDEX { get; set; }

        public double CURRENT_BEST_VALUE { get; set; }

        public double DUAL_BOUND { get; set; }

        public double SUM_CURRENT_DUAL { get; set; }

        public double PRIMAL_BOUND { get; set; }

        public double ACTION_VALUE { get; set; }

        public double VALUE_FUNCTION_ESTIMATE { get; set; }

        public bool IS_AFTER_FILTERING { get; set; }

    }
}
