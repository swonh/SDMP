﻿using Nodez.Data.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace $safeprojectname$.MyObjects
{
    public static class Parameter
    {
        // Define parameters here

        /// <summary>
        /// Example
        /// </summary>
        public static int PARAM_1 = 10;
    }
}
