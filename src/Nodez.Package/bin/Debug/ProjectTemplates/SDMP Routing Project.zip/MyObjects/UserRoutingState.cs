﻿using Nodez.Sdmp.General.DataModel;
using Nodez.Sdmp.Routing.DataModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace $safeprojectname$.MyObjects
{
    public class UserRoutingState : RoutingState
    {
        // Define user-specific state properties or methods here
    }
}
