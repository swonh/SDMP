﻿using Nodez.Data.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace $safeprojectname$.MyObjects
{
    public static class Parameter
    {
        // Define parameters here


        public static DateTime PLAN_START_TIME = new DateTime(2022, 12, 01, 00, 00, 00);
    }
}
